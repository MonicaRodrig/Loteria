﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Loteria2
{
    public partial class Form1 : Form
    {
        IPAddress ip;
        int port = 5000;
        TcpClient client;
        NetworkStream ns;
        Thread thread;
        bool conexion = true;

        SpeechSynthesizer s = new SpeechSynthesizer();

        int[,] A = new int[5,5];
        int[] B = new int[30];
        string[] C = new string[30];
        string noCarta;
        string cadena="";
        int min = 0, h = 0, seg = 0;
        int n = 0;
        public Form1()
        {
            //if (intentarConectarse().Equals("true"))
            //{
                InitializeComponent();
                agrega();
                aleatorio();
            concatenar();
            
            //agrega();
            // aleatorio();
            //}

        }

        private bool intentarConectarse()
        {
            bool opc = true;
            ip = IPAddress.Parse("127.0.0.1");
            port = 5000;
            client = new TcpClient();

            try
            {
                client.Connect(ip, port);
                ns = client.GetStream();
                thread = new Thread(o => ReceiveData((TcpClient)o));
                thread.Start(client);
            }
            catch (Exception a)
            {
                MessageBox.Show("No es posible conectarse. " + a.ToString());
                conexion = false;
                opc = false;
                cerrarCliente();
            }
            return opc;
        }

        void ReceiveData(TcpClient client)
        {
            byte[] receiveBytes = new byte[1024];
            int byte_count;

            while ((byte_count = ns.Read(receiveBytes, 0, receiveBytes.Length)) > 0)
            {
                cadena = Encoding.ASCII.GetString(receiveBytes, 0, byte_count);
                //MessageBox.Show(cadena);
                if(cadena.Length == 1)
                {
                    timer1.Stop();
                }
                else
                {
                    if (cadena.Length == 80)
                    {
                        C = cadena.Split('.');
                        for (int i = 0; i < 30; i++)
                        {
                            B[i] = Int32.Parse(C[i]);
                        }
                    }
                    else
                    {
                        C = cadena.Split('.');
                        seg = Int32.Parse(C[0]);
                        min = Int32.Parse(C[1]);
                        //h = Int16.Parse(C[2]);

                    }
                   
                }
                
            }
        }

        private void cerrarCliente()
        {
            client.Client.Shutdown(SocketShutdown.Send);
            thread.Join();
            ns.Close();
            client.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            if (intentarConectarse().Equals("true"))
            {
                
            }
        }

        private void concatenar()
        {
            for(int i = 0; i < 30; i++)
            {
                if (i == 29)
                {
                    cadena += B[i].ToString();
                }
                else
                {
                    cadena += B[i].ToString() + ".";
                }
                
                //MessageBox.Show(cadena);
            }
        }

        private void agrega()
        {
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
            comboBox1.Items.Add("3");
            comboBox1.Items.Add("4");
            comboBox1.Items.Add("5");
        }
        public Image SeleccionCarta(int id)
        {
            if (id == 1)
            {
                return global::Loteria2.Properties.Resources._1;
            }
            if (id == 2)
            {
                return global::Loteria2.Properties.Resources._2;
            }

            if (id == 3)
            {
                return global::Loteria2.Properties.Resources._3;
            } 
            if (id == 4)
            {
                return global::Loteria2.Properties.Resources._4;
            }
            if (id == 5)
            {
                return global::Loteria2.Properties.Resources._5;
            }
            if (id == 6)
            {
                return global::Loteria2.Properties.Resources._6;
            }
            if (id == 7)
            {
                return global::Loteria2.Properties.Resources._7;
            }
            if (id == 8)
            {
                return global::Loteria2.Properties.Resources._8;
            }
            if (id == 9)
            {
                return global::Loteria2.Properties.Resources._9;
            }
            if (id == 10)
            {
                return global::Loteria2.Properties.Resources._10;
            }
            if (id == 11)
            {
                return global::Loteria2.Properties.Resources._11;
            }
            if (id == 12)
            {
                return global::Loteria2.Properties.Resources._12;
            }
            if (id == 13)
            {
                return global::Loteria2.Properties.Resources._13;
            }
            if (id == 14)
            {
                return global::Loteria2.Properties.Resources._14;
            }
            if (id == 15)
            {
                return global::Loteria2.Properties.Resources._15;
            }
            if (id == 16)
            {
                return global::Loteria2.Properties.Resources._16;
            }
            if (id == 17)
            {
                return global::Loteria2.Properties.Resources._17;
            }
            if (id == 18)
            {
                return global::Loteria2.Properties.Resources._18;
            }
            if (id == 19)
            {
                return global::Loteria2.Properties.Resources._19;
            }
            if (id == 20)
            {
                return global::Loteria2.Properties.Resources._20;
            }
            if (id == 21)
            {
                return global::Loteria2.Properties.Resources._21;
            }
            if (id == 22)
            {
                return global::Loteria2.Properties.Resources._22;
            }
            if (id == 23)
            {
                return global::Loteria2.Properties.Resources._23;
            }
            if (id == 24)
            {
                return global::Loteria2.Properties.Resources._24;
            }
            if (id == 25)
            {
                return global::Loteria2.Properties.Resources._25;
            }
            if (id == 26)
            {
                return global::Loteria2.Properties.Resources._26;
            }
            if (id == 27)
            {
                return global::Loteria2.Properties.Resources._27;
            }
            if (id == 28)
            {
                return global::Loteria2.Properties.Resources._28;
            }
            if (id == 29)
            {
                return global::Loteria2.Properties.Resources._29;
            }
            if (id == 30)
            {
                return global::Loteria2.Properties.Resources._30;
            }
            return global::Loteria2.Properties.Resources._1;
        }
        private void ordenar()
        {
            this.pictureBox1.Image =SeleccionCarta(A[0,0]);
            this.pictureBox3.Image = SeleccionCarta(A[0, 1]);
            this.pictureBox4.Image = SeleccionCarta(A[0, 2]);
            this.pictureBox6.Image = SeleccionCarta(A[0, 3]);
            this.pictureBox5.Image = SeleccionCarta(A[1, 0]);
            this.pictureBox8.Image = SeleccionCarta(A[1, 1]);
            this.pictureBox7.Image = SeleccionCarta(A[1, 2]);
            this.pictureBox9.Image = SeleccionCarta(A[1, 3]);
            this.pictureBox13.Image = SeleccionCarta(A[2, 0]);
            this.pictureBox11.Image = SeleccionCarta(A[2, 1]);
            this.pictureBox12.Image = SeleccionCarta(A[2, 2]);
            this.pictureBox10.Image = SeleccionCarta(A[2, 3]);
            this.pictureBox17.Image = SeleccionCarta(A[3, 0]);
            this.pictureBox15.Image = SeleccionCarta(A[3, 1]);
            this.pictureBox16.Image = SeleccionCarta(A[3, 2]);
            this.pictureBox14.Image = SeleccionCarta(A[3, 3]);
        }
        private void cartas()
        {
            noCarta = comboBox1.SelectedItem.ToString();
            if (noCarta.Equals("1")){
                Console.WriteLine("entra 1");
                A[0, 0] = 1;
                A[0, 1] = 2;
                A[0, 2] = 3;
                A[0, 3] = 4;
                A[1, 0] = 5;
                A[1, 1] = 6;
                A[1, 2] = 7;
                A[1, 3] = 8;
                A[2, 0] = 9;
                A[2, 1] = 10;
                A[2, 2] = 11;
                A[2, 3] = 12;
                A[3, 0] = 13;
                A[3, 1] = 14;
                A[3, 2] = 15;
                A[3, 3] = 16;
            }
            if (noCarta.Equals("2")){
                A[0, 0] = 17;
                A[0, 1] = 18;
                A[0, 2] = 19;
                A[0, 3] = 20;
                A[1, 0] = 21;
                A[1, 1] = 22;
                A[1, 2] = 23;
                A[1, 3] = 24;
                A[2, 0] = 25;
                A[2, 1] = 26;
                A[2, 2] = 27;
                A[2, 3] = 28;
                A[3, 0] = 29;
                A[3, 1] = 30;
                A[3, 2] = 6;
                A[3, 3] = 13;
            }
            if (noCarta.Equals("3")){
                A[0, 0] = 20;
                A[0, 1] = 27;
                A[0, 2] = 7;
                A[0, 3] = 14;
                A[1, 0] = 21;
                A[1, 1] = 28;
                A[1, 2] = 8;
                A[1, 3] = 15;
                A[2, 0] = 22;
                A[2, 1] = 29;
                A[2, 2] = 2;
                A[2, 3] = 9;
                A[3, 0] = 16;
                A[3, 1] = 1;
                A[3, 2] = 23;
                A[3, 3] = 30;
            }
            if (noCarta.Equals("4")){
                A[0, 0] = 3;
                A[0, 1] = 10;
                A[0, 2] = 17;
                A[0, 3] = 24;
                A[1, 0] = 4;
                A[1, 1] = 11;
                A[1, 2] = 18;
                A[1, 3] = 25;
                A[2, 0] = 5;
                A[2, 1] = 12;
                A[2, 2] = 19;
                A[2, 3] = 26;
                A[3, 0] = 1;
                A[3, 1] = 6;
                A[3, 2] = 13;
                A[3, 3] = 9;
            }
            if (noCarta.Equals("5")){
                A[0, 0] = 30;
                A[0, 1] = 6;
                A[0, 2] = 16;
                A[0, 3] = 21;
                A[1, 0] = 5;
                A[1, 1] = 12;
                A[1, 2] = 27;
                A[1, 3] = 9;
                A[2, 0] = 18;
                A[2, 1] = 24;
                A[2, 2] = 21;
                A[2, 3] = 4;
                A[3, 0] = 20;
                A[3, 1] = 17;
                A[3, 2] = 3;
                A[3, 3] = 28;
            }
            byte[] buffer = Encoding.ASCII.GetBytes(cadena);
            ns.Write(buffer, 0, buffer.Length);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cartas();
            ordenar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex != -1)
            {
               
                button1.Enabled = false;
                comboBox1.Enabled = false;
                imagen(B[n]);
                n++;
                buscar();
                this.timer1.Start();
            }
            else
            {
                MessageBox.Show("Se necesita seleccionar un carton");
            }
        }

        public void imagen(int id)
        {
            if (id == 1)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._38;
                s.Speak("La araña");
            }
            if (id == 2)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._32;
                s.Speak("El soldado");
            }

            if (id == 3)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._33;
                s.Speak("El cotorro");
            }
            if (id == 4)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._34;
                s.Speak("El valiente");
            }
            if (id == 5)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._35;
                s.Speak("La capana");
            }
            if (id == 6)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._36;
                s.Speak("El tambor");
            }
            if (id == 7)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._37;
                s.Speak("El venado");
            }
            if (id == 8)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._39;
                s.Speak("El violoncello");
            }
            if (id == 9)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._40;
                s.Speak("El pajaro");
            }
            if (id == 10)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._41;
                s.Speak("El gallo");
            }
            if (id == 11)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._42;
                s.Speak("La rosa");
            }
            if (id == 12)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._43;
                s.Speak("El mundo");
            }
            if (id == 13)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._44;
                s.Speak("El bandolón");
            }
            if (id == 14)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._45;
                s.Speak("La maceta");
            }
            if (id == 15)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._46;
                s.Speak("El borracho");
            }
            if (id == 16)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._47;
                s.Speak("La pera");
            }
            if (id == 17)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._48;
                s.Speak("El melon");
            }
            if (id == 18)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._49;
                s.Speak("La sirena");
            }
            if (id == 19)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._50;
                s.Speak("El paraguas");
            }
            if (id == 20)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._51;
                s.Speak("El nopal");
            }
            if (id == 21)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._52;
                s.Speak("La dama");
            }
            if (id == 22)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._53;
                s.Speak("La bandera");
            }
            if (id == 23)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._54;
                s.Speak("La luna");
            }
            if (id == 24)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._55;
                s.Speak("La botella");
            }
            if (id == 25)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._56;
                s.Speak("El arpa");
            }
            if (id == 26)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._57;
                s.Speak("Las aras");
            }
            if (id == 27)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._58;
                s.Speak("La calabera");
                
            }
            if (id == 28)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._59;
                s.Speak("La mano");
            }
            if (id == 29)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._60;
                 s.Speak("El apache");
            }
            if (id == 30)
            {
                this.pictureBox2.Image = global::Loteria2.Properties.Resources._31;
                s.Speak("El arbol");
            }
        }

        
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            seg++;
            if (seg == 60)
            {
                imagen(B[n]);
                min++;
                seg = 0;
                n++;
                buscar();
                if (min == 60)
                {
                    h++;
                    min = 0;
                }

            }

            byte[] buffer = Encoding.ASCII.GetBytes(seg+"."+min+"."+h);
            
            ns.Write(buffer, 0, buffer.Length);
            if (n == 30)
            {
                this.timer1.Stop();
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            this.pictureBox6.Image = SeleccionCartaBW(B[n-1]);
            A[0, 3] = 0;
            ganador();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Image = SeleccionCartaBW(B[n-1]);
            A[0, 0] = 0;
            ganador();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.pictureBox3.Image = SeleccionCartaBW(B[n-1]);
            A[0, 1] = 0;
            ganador();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.pictureBox4.Image = SeleccionCartaBW(B[n-1]);
            A[0, 2] = 0;
            ganador();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.pictureBox5.Image = SeleccionCartaBW(B[n-1]);
            A[1, 0] = 0;
            ganador();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.pictureBox8.Image = SeleccionCartaBW(B[n-1]);
            A[1, 1] = 0;
            ganador();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            this.pictureBox7.Image = SeleccionCartaBW(B[n-1]);
            A[1, 2] = 0;
            ganador();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            this.pictureBox9.Image = SeleccionCartaBW(B[n-1]);
            A[1, 3] = 0;
            ganador();
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            this.pictureBox13.Image = SeleccionCartaBW(B[n-1]);
            A[2, 0] = 0;
            ganador();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            this.pictureBox11.Image = SeleccionCartaBW(B[n-1]);
            A[2, 1] = 0;
            ganador();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            this.pictureBox12.Image = SeleccionCartaBW(B[n-1]);
            A[2, 2] = 0;
            ganador();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            this.pictureBox10.Image = SeleccionCartaBW(B[n-1]);
            A[2, 3] = 0;
            ganador();
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            this.pictureBox17.Image = SeleccionCartaBW(B[n-1]);
            A[3, 0] = 0;
            ganador();
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            this.pictureBox15.Image = SeleccionCartaBW(B[n-1]);
            A[3, 1] = 0;
            ganador();
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            this.pictureBox16.Image = SeleccionCartaBW(B[n-1]);
            A[3, 2] = 0;
            ganador();
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            this.pictureBox14.Image = SeleccionCartaBW(B[n-1]);
            A[3, 3] = 0;
            ganador();
        }

        private void aleatorio()
        {
            int num = 1;
            while (num != 31)
            {
                Random rnd = new Random();
                int carta = rnd.Next(30);

                if (B[carta] == 0)
                {
                    B[carta] = num;
                    num++;
                }
            }
            for(int i = 0; i < 30; i++)
            {
                Console.WriteLine(B[i]);
            }
        }
        private void buscar()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (A[i, j] == B[n-1])
                    {
                        //cambiar(SeleccionCartaBW(B[n - 1]),i,j);
                        DesBloq(i, j);
                    }
                    else
                    {
                        Bloq(i, j);
                    }
                }
            }
        }
        private void DesBloq(int x, int y)
        {
            if (x == 0 && y == 0)
            {
                this.pictureBox1.Enabled = true;
            }
            if (x == 0 && y == 1)
            {
                this.pictureBox3.Enabled = true;
            }
            if (x == 0 && y == 2)
            {
                this.pictureBox4.Enabled = true;
            }
            if (x == 0 && y == 3)
            {
                this.pictureBox6.Enabled = true;
            }
            if (x == 1 && y == 0)
            {
                this.pictureBox5.Enabled = true;
            }
            if (x == 1 && y == 1)
            {
                this.pictureBox8.Enabled = true;
            }
            if (x == 1 && y == 2)
            {
                this.pictureBox7.Enabled = true;
            }
            if (x == 1 && y == 3)
            {
                this.pictureBox9.Enabled = true;
            }
            if (x == 2 && y == 0)
            {
                this.pictureBox13.Enabled = true;
            }
            if (x == 2 && y == 1)
            {
                this.pictureBox11.Enabled = true;
            }
            if (x == 2 && y == 2)
            {
                this.pictureBox12.Enabled = true;
            }
            if (x == 2 && y == 3)
            {
                this.pictureBox10.Enabled = true;
            }
            if (x == 3 && y == 0)
            {
                this.pictureBox17.Enabled = true;
            }
            if (x == 3 && y == 1)
            {
                this.pictureBox15.Enabled = true;
            }
            if (x == 3 && y == 2)
            {
                this.pictureBox16.Enabled = true;
            }
            if (x == 3 && y == 3)
            {
                this.pictureBox14.Enabled = true;
            }
        }

        private void Bloq(int x, int y)
        {
            if (x == 0 && y == 0)
            {
                this.pictureBox1.Enabled = false;
            }
            if (x == 0 && y == 1)
            {
                this.pictureBox3.Enabled = false;
            }
            if (x == 0 && y == 2)
            {
                this.pictureBox4.Enabled = false;
            }
            if (x == 0 && y == 3)
            {
                this.pictureBox6.Enabled = false;
            }
            if (x == 1 && y == 0)
            {
                this.pictureBox5.Enabled = false;
            }
            if (x == 1 && y == 1)
            {
                this.pictureBox8.Enabled = false;
            }
            if (x == 1 && y == 2)
            {
                this.pictureBox7.Enabled = false;
            }
            if (x == 1 && y == 3)
            {
                this.pictureBox9.Enabled = false;
            }
            if (x == 2 && y == 0)
            {
                this.pictureBox13.Enabled = false;
            }
            if (x == 2 && y == 1)
            {
                this.pictureBox11.Enabled = false;
            }
            if (x == 2 && y == 2)
            {
                this.pictureBox12.Enabled = false;
            }
            if (x == 2 && y == 3)
            {
                this.pictureBox10.Enabled = false;
            }
            if (x == 3 && y == 0)
            {
                this.pictureBox17.Enabled = false;
            }
            if (x == 3 && y == 1)
            {
                this.pictureBox15.Enabled = false;
            }
            if (x == 3 && y == 2)
            {
                this.pictureBox16.Enabled = false;
            }
            if (x == 3 && y == 3)
            {
                this.pictureBox14.Enabled = false;
            }
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        /*private void cambiar(Image i,int x,int y)
        {
            if(x==0 && y == 0)
            {
                this.pictureBox1.Image = i;
            }
            if (x == 0 && y == 1)
            {
                this.pictureBox3.Image = i;
            }
            if (x == 0 && y == 2)
            {
                this.pictureBox4.Image = i;
            }
            if (x == 0 && y == 3)
            {
                this.pictureBox6.Image = i;
            }
            if (x == 1 && y == 0)
            {
                this.pictureBox5.Image = i;
            }
            if (x == 1 && y == 1)
            {
                this.pictureBox8.Image = i;
            }
            if (x == 1 && y == 2)
            {
                this.pictureBox7.Image = i;
            }
            if (x == 1 && y == 3)
            {
                this.pictureBox9.Image = i;
            }
            if (x == 2 && y == 0)
            {
                this.pictureBox13.Image = i;
            }
            if (x == 2 && y == 1)
            {
                this.pictureBox11.Image = i;
            }
            if (x == 2 && y == 2)
            {
                this.pictureBox12.Image = i;
            }
            if (x == 2 && y == 3)
            {
                this.pictureBox10.Image = i;
            }
            if (x == 3 && y == 0)
            {
                this.pictureBox17.Image = i;
            }
            if (x == 3 && y == 1)
            {
                this.pictureBox15.Image = i;
            }
            if (x == 3 && y == 2)
            {
                this.pictureBox16.Image = i;
            }
            if (x == 3 && y == 3)
            {
                this.pictureBox14.Image = i;
            }

        }*/

        public Image SeleccionCartaBW(int id)
        {
            if (id == 1)
            {
                return global::Loteria2.Properties.Resources._1_2;
            }
            if (id == 2)
            {
                return global::Loteria2.Properties.Resources._2_2;
            }

            if (id == 3)
            {
                return global::Loteria2.Properties.Resources._3_2;
            }
            if (id == 4)
            {
                return global::Loteria2.Properties.Resources._4_2;
            }
            if (id == 5)
            {
                return global::Loteria2.Properties.Resources._5_2;
            }
            if (id == 6)
            {
                return global::Loteria2.Properties.Resources._6_2;
            }
            if (id == 7)
            {
                return global::Loteria2.Properties.Resources._7_2;
            }
            if (id == 8)
            {
                return global::Loteria2.Properties.Resources._8_2;
            }
            if (id == 9)
            {
                return global::Loteria2.Properties.Resources._9_2;
            }
            if (id == 10)
            {
                return global::Loteria2.Properties.Resources._10_2;
            }
            if (id == 11)
            {
                return global::Loteria2.Properties.Resources._11_2;
            }
            if (id == 12)
            {
                return global::Loteria2.Properties.Resources._12_2;
            }
            if (id == 13)
            {
                return global::Loteria2.Properties.Resources._13_2;
            }
            if (id == 14)
            {
                return global::Loteria2.Properties.Resources._14_2;
            }
            if (id == 15)
            {
                return global::Loteria2.Properties.Resources._15_2;
            }
            if (id == 16)
            {
                return global::Loteria2.Properties.Resources._16_2;
            }
            if (id == 17)
            {
                return global::Loteria2.Properties.Resources._17_2;
            }
            if (id == 18)
            {
                return global::Loteria2.Properties.Resources._18_2;
            }
            if (id == 19)
            {
                return global::Loteria2.Properties.Resources._19_2;
            }
            if (id == 20)
            {
                return global::Loteria2.Properties.Resources._20_3;
            }
            if (id == 21)
            {
                return global::Loteria2.Properties.Resources._21_2;
            }
            if (id == 22)
            {
                return global::Loteria2.Properties.Resources._22_2;
            }
            if (id == 23)
            {
                return global::Loteria2.Properties.Resources._23_2;
            }
            if (id == 24)
            {
                return global::Loteria2.Properties.Resources._24_2;
            }
            if (id == 25)
            {
                return global::Loteria2.Properties.Resources._25_2;
            }
            if (id == 26)
            {
                return global::Loteria2.Properties.Resources._26_2;
            }
            if (id == 27)
            {
                return global::Loteria2.Properties.Resources._27_2;
            }
            if (id == 28)
            {
                return global::Loteria2.Properties.Resources._28_2;
            }
            if (id == 29)
            {
                return global::Loteria2.Properties.Resources._29_2;
            }
            if (id == 30)
            {
                return global::Loteria2.Properties.Resources._30_2;
            }
            return global::Loteria2.Properties.Resources._1;
        }

        private void ganador()
        {
            string win = "0";
            for(int i = 0; i < 4; i++)
            {
                if(A[i,0]==0 && A[i,1]==0 && A[i,2]==0 && A[i, 3] == 0)
                {
                    win = "1";
                    MessageBox.Show("Ganaste");
                    timer1.Stop();
                }

                if (A[0, i] == 0 && A[1, i] == 0 && A[2, i] == 0 && A[3, i] == 0)
                {
                    win = "1";
                    MessageBox.Show("Ganaste");
                    timer1.Stop();
                }

            }
            if (A[0, 0] == 0 && A[1, 1] == 0 && A[2, 2] == 0 && A[3, 3] == 0)
            {
                win = "1";
                MessageBox.Show("Ganaste");
                timer1.Stop();
            }
            if (A[0, 3] == 0 && A[1, 2] == 0 && A[2, 1] == 0 && A[3, 0] == 0)
            {
                win = "1";
                MessageBox.Show("Ganaste");
                timer1.Stop();
            }
            if (win.Equals ("1"))
            {
               byte[] buffer = Encoding.ASCII.GetBytes(win);
                ns.Write(buffer, 0, buffer.Length);
            }
            
        }
    }
}
