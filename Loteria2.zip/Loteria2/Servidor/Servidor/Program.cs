﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace Servidor
{
    class Program
    {
        static readonly object _lock = new object();
        static readonly Dictionary<int, TcpClient> list_clients = new Dictionary<int, TcpClient>();
        public static int count = 0;

        static void Main(string[] args)
        {
            TcpListener ServerSocket = new TcpListener(IPAddress.Any, 5000);
            ServerSocket.Start();

            while (true)
            {
                TcpClient client = ServerSocket.AcceptTcpClient();
                if (count <= 2)
                {
                    lock (_lock) list_clients.Add(count, client);
                    Console.WriteLine(count + " client connected!!");
                    Thread t = new Thread(handle_clients);
                    t.Start(count);
                }
                else
                {

                    client.Client.Shutdown(SocketShutdown.Both);
                    client.Close();
                }
                count++;
            }
        }
        public static void handle_clients(Object o)
        {
            int id = (int)o;
            TcpClient client;

            lock (_lock) client = list_clients[id];
            while (true)
            {
                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[1024];
                int byte_count = stream.Read(buffer, 0, buffer.Length);
                Console.WriteLine("leyendo");
                if (byte_count == 0)
                {
                    break;
                }
                string data = Encoding.ASCII.GetString(buffer, 0, byte_count);
                broadcast(data);
                Console.WriteLine(data);
            }
            lock (_lock) list_clients.Remove(id);
            client.Client.Shutdown(SocketShutdown.Both);
            client.Close();
            count--;
            Console.WriteLine(count.ToString());
            if (count == 0)
                Console.Clear();
        }

        public static void broadcast(string data)
        {
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            lock (_lock)
            {
                foreach (TcpClient c in list_clients.Values)
                {
                    Console.WriteLine("escribiendo");
                    NetworkStream stream = c.GetStream();
                    stream.Write(buffer, 0, buffer.Length);
                }
            }
        }


    }
}
